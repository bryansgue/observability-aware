IEEE Access resubmission — Access-2026-36061
"Identifiability-Aware Virtual Force Sensing and Self-Calibration for Quadrotors"

Portal upload mapping:
  Author's Response Files ....... response/response.pdf  (or response.docx)
  Highlighted PDF ............... paper_access_highlighted.pdf  (changes vs round 1 in blue)
  Main Manuscript (source) ...... main_manuscript_source/  (LaTeX; compile paper_access.tex)
  Main Manuscript - PDF ......... paper_access.pdf

Overleaf: upload main_manuscript_source/ (or overleaf_resubmission.zip) as one
project; it contains THREE compilable documents (manuscript, highlighted,
response letter) — see its README_OVERLEAF.txt.
